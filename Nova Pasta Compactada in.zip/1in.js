var num = parseInt(prompt('digite um número:'));
//Criei uma variavél e adiciona uma resposta a variável
if (num > 0){
    alert('Seu número é positivo');
    //Primeira opção de teste lógico
}else if (num < 0){
    alert('Seu número é negativo');
    //Segunda opção de teste lógico
}else{
    alert('Seu número é neutro');
    //Caso não seja nenhuma opção anterior, será essa!
}; 
